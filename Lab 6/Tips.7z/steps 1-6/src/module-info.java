module tip {
    requires javafx.fxml;
    requires javafx.controls;
    exports tip;
    opens tip;
}