package maze.model;

//Create an implementation that passes all tests in MazeTest.

public class Maze {

	private Cell[][] cells;

	public Maze(int width, int height) {
		// TODO STEP 1 Complete this method
	}

	public int getWidth() {
		// TODO STEP 1 Complete this method
		return 0;
	}

	public int getHeight() {
		// TODO STEP 1 Complete this method
		return 0;
	}

	public boolean inMaze(Position p) {
		// TODO STEP 1 Complete this method
		return false;
	}

	public Cell getStateFor(Position p) {
		// TODO STEP 1 Complete this method
		return null;
	}

	public void setStateFor(Position p, Cell state) {
		// TODO STEP 1 Complete this method
	}
}
