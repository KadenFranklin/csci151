package maze.model;

// Create an implementation that passes all tests in MoveTest.

public enum Move {

    // TODO Step 4 Write This Enum
	
}
